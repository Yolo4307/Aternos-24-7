const {mineboty} = require("mineboty")
mineboty();
